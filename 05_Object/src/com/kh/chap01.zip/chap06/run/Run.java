package com.kh.chap06.run;

import com.kh.chap06.controller.MethodController;

public class Run {
	public static void main(String[] args) {
		
		MethodController m1 = new MethodController();
		// 학습방법 => 소리내어 입으로 읽자!
		MethodController m2 = new MethodController();
		MethodController m3 = new MethodController();
		int a = m1.add(2, 3);
		int b = m1.add(4, 5);
		System.out.println(a);
		System.out.println(b);
		System.out.println(m3.fn(99));
		System.out.println(m2.fn2()); //print(안에는 "값"만 들어갈 수 있다.)
		
		m1.method();
		m2.method(2);	
	}
	
	

}
