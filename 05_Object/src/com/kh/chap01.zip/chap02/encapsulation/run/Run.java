package com.kh.chap02.encapsulation.run;

import java.util.Scanner;

import com.kh.chap02.encapsulation.model.vo.CellPhone;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 스마트폰 정보를 저장해야겠구나?
		CellPhone cp = new CellPhone();
		// CellPhone 변수선언, heap에 CellPhone 서랍장을 만든다.
		// CellPhone은 여기서 주소값. 그래서 아래와 같이 사용도 가능.
		// new CellPhone.hi(); vs. cp.hi();
		// 1회용 vs. 계속 재사용 여부
		// 자바에서 변수 공간에 쓰이는 값 10가지 종류
		// 기본(Booelean, char, byte, short, int, long, float, double
		// 참조(주소값, null값) / 여기서 주소값 = 객체
		/*
		 * cp.productName = "아이폰18pro";
		 * System.out.println(cp.productName);
		 * cp.size = -8.0;
		 * System.out.println(cp.size);
		 * 필드가 외부에서 보이지 않도록 캡슐를 사용		
		*/		
		// 캡슐화 : 압축하고 숨기는 과정.
		// private 
		
		/* DTO
		 * setter 만들기 규칙
		 * 1. 외부에서 접근이 가능해야 하기 때문에 public void로 선언
		 * 2. set 필드명으로 식별자를 작성 낙타봉표기법
		 */
		
		
		/*cp.setColor();
		 * System.out.println(cp.getColor());
		 * String color = cp.getColor();
		 * cp.setProductName("갤럭시폴드7");
		 * cp.setNetworkProvider("KT");
		*/
		
		Scanner sc = new Scanner(System.in);
		System.out.println("다음의 항목들을 작성하시오.");
		System.out.println("휴대폰 기종"
						 + "\n통신사"
						 + "\n인치"
						 + "\n색상");
						 
		cp.setProductName(sc.nextLine());
		cp.setNetworkProvider(sc.nextLine());
		cp.setSize(sc.nextDouble());
		cp.setColor(sc.nextLine());
		
		String productName = cp.getProductName();
		String networkProvider = cp.getNetworkProvider();
		double size = cp.getSize();
		String color = cp.getColor();
		
		System.out.println("스마트폰 = 제품명 : " + productName
						 + "\n색상 : " + color 
						 + "\n사이즈 : " + size + "inch"
						 + "\n통신사 : " + networkProvider);
						 
		//cp.setSize(1.0); // size 필드 값을 세팅
					// argument, 인자값, 인수
		// cp를 .참조 하는 setSize 메소드를 호출
		//System.out.println("메인메소드 35행 : " + cp);
		
		cp.getSize(); // 사이즈 내놔! 모든 명령문은 실제로 명령을 지시한다는 생각으로 사용하면 좋다.
		
	
		System.out.println(cp.getSize());
		
		System.out.println(size);
		
		/*
		 * 접근제한자는 4가지 항목이 있음.
		 * AccessModifier (접근제한자/제어자)
		 * public => 어디서든(같은 패키지, 다른패키지, 클래스 내/외부 전부 포함) 접근 가능
		 * protected => 같은 패키지라면 무조건 접근 가능!
		 * 			 => 다른 패키지면, 상속구조인 클래스에만 접근 가능
		 * 			 => 상속은 chap07에서 배울 예정
		 * default(package friendly)=> 같은 패키지 내에서만 접근 가능
		 * private =>
		 */
		
		
		
		

		
	} 
		
	
		
}
		
		

