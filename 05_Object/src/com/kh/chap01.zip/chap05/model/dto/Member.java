package com.kh.chap05.model.dto;

public class Member {
	//필드부
	private String userID;
	private String userPwd;
	private String nickName;
	//생성자부
	/*
	 * 생성자의 두가지 관점
	 * 
	 * [기술]
	 * 
	 * [관점]
	 * 
	 * 
	 * [기본생성자 = 매개변수가 없는 생성자(객체의 초기화) 표현법]
	 * 접근제한자 클래스 식별자(){ } 
	 */
	
		
	
	// 메소드부 (액션)(
	//(getter, setter, info) => 만들기 시작
	public void setUserID(String userId) {
		this.userID = userId;
	}	
		
	public String getUserID() {
		return userID;
	}
	
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getUserPwd() {
		return userPwd;		
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getNickName() {
		return nickName;
	}
	public String info() {
		return "아이디: " + userID 
			+ "\n패스워드: " + userPwd
			+ "\n닉네임: " + nickName;			
	}
	/* public Member(String userID) {
		System.out.println("아이디 값 초기화");
		this.userID = userID;
	} */
	
	public Member() {}
	
	public Member(String userId) {
		System.out.println("아이디 값 초기화");
		this.userID = userId;
	}
	public Member(String userId, String userPwd) {
		System.out.println("비밀번호 호출");
		this.userID = userID;
		this.userPwd = userPwd;		
	}
	public Member(String userId, String userPwd, String nickName) {
		this.userID = userID;
		this.userPwd = userPwd;	
		this.nickName = nickName;
	}
		
	
	
}
